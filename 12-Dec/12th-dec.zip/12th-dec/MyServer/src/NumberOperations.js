export function sum(a,b){
    return a+b;
}

export function factorial(n){
    var f=1;
    for(var i=1;i<=n;i++){
        f=f*i;
    }    
    return f;
}
